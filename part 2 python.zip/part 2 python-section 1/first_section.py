import json
import pandas as pd

assets_folder = "data-grades/"
xlWriter = pd.ExcelWriter("Result.xlsx", engine='xlsxwriter')

# Read JSON data
with open(assets_folder + "Students.json", "r") as f:
    students = json.loads(json.loads(f.read()))
    
student_df = pd.DataFrame(students)

# Read CSV files
quiz_1_df = pd.read_csv(assets_folder + "quiz_1_grades.csv")
quiz_2_df = pd.read_csv(assets_folder + "quiz_2_grades.csv")
h_and_e_df = pd.read_csv(assets_folder + "Homework and exams.csv")

# Merge DataFrames
merged_df = pd.merge(quiz_1_df, quiz_2_df, on=["Last Name", "First Name"])
merged_df = pd.merge(merged_df, h_and_e_df, on=["Last Name", "First Name"])

# Calculate final grades
final_grades = (((merged_df["Grade_x"] * 10) + (merged_df["Grade_y"] * 10)) / (4 * 2)) + (
    (merged_df["Homework 1"] + merged_df["Homework 2"] + merged_df["Homework 3"]) / (10 * 3)
) + (merged_df["Exam"] * 65 / 100)

merged_df["Final Grade"] = final_grades

# Split full names into first name and last name
student_df[["Last Name", "First Name"]] = student_df["Name"].str.split(",", expand=True)
student_df["First Name"] = student_df["First Name"].str.split(expand=True)[0]
student_df["Last Name"] = student_df["Last Name"].str.split(expand=True)[0]

# Merge DataFrames and sort by final grades
merged_df = pd.merge(
    merged_df, student_df[["Group", "First Name", "Last Name", "Name", "ID"]], on=["Last Name", "First Name"]
).sort_values(by=["Final Grade"], ascending=False)

# Write data to separate sheets for each group
for i in range(1, 4):
    group_df = merged_df[merged_df["Group"] == i]
    group_df = group_df[["Name", "ID", "Final Grade"]]
    group_df = group_df.rename(columns={"Name": "Student Name", "ID": "Student ID"})
    group_df.to_excel(xlWriter, sheet_name="Group " + str(i), index=False)

xlWriter.close()