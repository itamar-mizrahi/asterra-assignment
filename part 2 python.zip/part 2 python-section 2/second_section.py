import numpy as np
import matplotlib.pyplot as plt

# Create a 1000x10000 array with random numbers ranging 0-65535
array_size = (1000, 10000)
original_array = np.random.randint(0, 65536, size=array_size)

# Calculate Log_data with a masked array to handle zero values
log_data = 10 * np.ma.log10(original_array**2)

# Calculate Final array with filtering invalid values
final_array = np.where((log_data < 13) & (~log_data.mask), 2 * log_data**2, original_array)

# Plot the final array as an image
plt.imshow(final_array, cmap='gray', aspect='auto')

# Save the image
plt.savefig('final_array_image.png')

# Show the plot (optional)
plt.show()
